#include <iostream>

#include "Livro.hpp"

Livro::Livro(string ISBN, string tituloDoLivro, Autor autor) : ISBN(ISBN), tituloDoLivro(tituloDoLivro), autor(autor)
{}

string Livro::getISBN(){
    return ISBN;
}
string Livro::getTituloDoLivro(){
    return tituloDoLivro;
}
Autor Livro::getAutor(){
    return autor;
}
